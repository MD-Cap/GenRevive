import logging
import os
import xml.etree.ElementTree as eTree

import javalang
from genrevive.helpers.common.file_utils import FileUtils


class ADFXmlUtils:
    def __init__(self, adf_directory_path):
        self.adf_directory_path = adf_directory_path
        logging.basicConfig(
            level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
        )

    def _find_files(self, extension):
        """Helper method to find all files with a specific extension in the directory and subdirectories."""
        found_files = []
        for root, _, files in os.walk(self.adf_directory_path):
            for file in files:
                if file.endswith(extension):
                    found_files.append(os.path.join(root, file))
        logging.debug(f"Found {len(found_files)} files with extension {extension}")
        return found_files

    def remove_namespace(self, tree):
        for elem in tree.iter():
            if "}" in elem.tag:
                elem.tag = elem.tag.split("}", 1)[1]  # Remove namespace prefix
        return tree

    def get_eo_as_descriptors_based_on_adf_entity_name(self, entity_name):
        eos_root = eTree.Element("root")
        entities_root = eTree.SubElement(eos_root, "Entities")
        associations_root = eTree.SubElement(eos_root, "Associations")
        found_entity = False
        found_association = False

        for dirpath, _, filenames in os.walk(self.adf_directory_path):
            for filename in filenames:
                if filename.endswith(".xml"):
                    file_path = os.path.join(dirpath, filename)
                    logging.debug(f"Processing file: {filename}")
                    try:
                        tree = eTree.parse(file_path)
                        tree = self.remove_namespace(tree)
                        for elem in tree.iter():
                            if elem.tag == "Entity" and entity_name in elem.attrib.get(
                                "Name", ""
                            ):
                                entities_root.append(elem)
                                found_entity = True
                                logging.info(f"Appending Entity from {filename}")
                            elif elem.tag == "Association":
                                # Assuming Association elements have references within attributes or sub-elements
                                if entity_name in eTree.tostring(elem, encoding="unicode"):
                                    associations_root.append(elem)
                                    found_association = True
                                    logging.info(
                                        f"Appending Association from {filename}"
                                    )
                    except eTree.ParseError as e:
                        logging.error(f"Error parsing {filename}: {e}")

        if not found_entity:
            logging.error(
                f"No entities containing '{entity_name}' were found in the directory."
            )
        if not found_association:
            logging.error(
                f"No associations related to '{entity_name}' were found in the directory."
            )

        return eTree.tostring(eos_root, encoding="unicode")

    def get_vo_content_and_path_by_vo_name(self, vo_name):
        """
        Search for XML ViewObject files by their name and return the content of the first match.
        """
        xml_files = self._find_files(".xml")
        namespace = {"ns": "http://xmlns.oracle.com/bc4j"}

        for file_path in xml_files:
            try:
                # Parse the XML file
                tree = eTree.parse(file_path)
                root = tree.getroot()

                # Check if the root tag is ViewObject with or without namespace
                if (
                    root.tag.endswith("ViewObject")
                    or root.tag == "{http://xmlns.oracle.com/bc4j}ViewObject"
                ):
                    # Extract the ViewObjectName
                    vo_name_attr = root.get("Name")
                    if vo_name_attr == vo_name:
                        # If a match is found, read and return the content
                        with open(file_path, "r", encoding="utf-8") as file:
                            return file.read(), file_path

            except eTree.ParseError as e:
                print(f"Error parsing {file_path}: {e}")
            except Exception as e:
                print(f"Unexpected error with file {file_path}: {e}")

        # Return None if no match is found
        return None, None

    def get_main_query_by_view_object_content(self, xml_data):
        # Strip leading/trailing whitespace to avoid parsing errors
        xml_data = xml_data.strip()

        # Parse XML data
        root = eTree.fromstring(xml_data)

        # Handling namespace
        namespace = {"ns": "http://xmlns.oracle.com/bc4j"}

        # First attempt to extract SelectList and FromList attributes
        select_list = (
            root.get("SelectList", "").strip().replace("\n", " ").replace("  ", " ")
        )
        from_list = root.get("FromList", "").strip()
        where = root.get("Where", "").strip()  # Handle optional Where

        if select_list and from_list:
            # Construct SQL query from SelectList and FromList if available
            select_part = f"SELECT {select_list}"
            tables = from_list.split(", ")
            from_part = f"FROM {','.join(tables)}"
            sql_query = select_part + "\n" + from_part

            if where:
                sql_query += f"\nWHERE {where}"

            return sql_query
        else:
            # If SelectList and FromList are not available, look for SQLQuery
            sql_query_element = root.find("ns:SQLQuery", namespaces=namespace)
            if sql_query_element is not None and sql_query_element.text:
                # Return the SQL directly from SQLQuery if available
                return sql_query_element.text.strip()

            # If neither SelectList nor SQLQuery is available, return None
            return None

    def get_view_criterias_by_view_object_content(self, xml_data):
        # Strip leading/trailing whitespace to avoid parsing errors
        xml_data = xml_data.strip()

        # Parse XML data
        root = eTree.fromstring(xml_data)

        # Handling namespace
        namespace = {"ns": "http://xmlns.oracle.com/bc4j"}

        # Find all ViewCriteria elements
        view_criterias = root.findall(".//ns:ViewCriteria", namespaces=namespace)

        # Dictionary to store view criteria names and their content
        view_criteria_dict = {}

        for vc in view_criterias:
            # Get the name of the view criteria
            vc_name = vc.get("Name")

            # Get the entire ViewCriteria element as a string
            vc_content = eTree.tostring(vc, encoding="unicode")

            # Store the name and content in the dictionary
            view_criteria_dict[vc_name] = vc_content

        return view_criteria_dict

    def get_java_methods(self, java_source_code):
        # Parse the Java source code
        tree = javalang.parse.parse(java_source_code)

        # Initialize a list to store method names
        method_names = []

        # Traverse the tree to find method declarations
        for path, node in tree:
            if isinstance(node, javalang.tree.MethodDeclaration):
                method_names.append(node.name)

        return method_names

    def get_component_class_from_vo(self, vo_path):
        try:
            # Parse the XML file
            tree = eTree.parse(vo_path)
            root = tree.getroot()

            # Check if the root tag is ViewObject with or without namespace
            if (
                root.tag.endswith("ViewObject")
                or root.tag == "{http://xmlns.oracle.com/bc4j}ViewObject"
            ):
                component_class = root.attrib.get("ComponentClass")
                if component_class:
                    return component_class
        except eTree.ParseError:
            print(f"Error parsing XML file: {vo_path}")
        except Exception as e:
            print(f"Unexpected error: {e}")

    # TODO: move to adf-project-helper
    def get_table_name_from_adf_entity(self, entity_name):
        xml_files = FileUtils.find_files_in_directory(".xml", self.adf_directory_path)
        for xml_file in xml_files:
            logging.debug(f"Processing ADF XML file: {xml_file}")
            try:
                tree = eTree.parse(xml_file)
                root_element = tree.getroot()
                if (
                    root_element.tag == "{http://xmlns.oracle.com/bc4j}Entity"
                ):  # Ensure it is an Entity tag
                    table_name = root_element.get("DBObjectName")
                    name = root_element.get("Name")
                    if name == entity_name:
                        return table_name
            except eTree.ParseError as e:
                logging.warning(f"Failed to parse XML file: {xml_file}. Error: {e}")
            except Exception as e:
                logging.error(
                    f"Unexpected error processing file: {xml_file}. Error: {e}"
                )
        return None
