import logging
import os

import docker
import oracledb
from testcontainers.oracle import OracleDbContainer


class OracleDbUtils:

    def __init__(self, schema_file_path, inserts_file_path):
        self.schema_file_path = schema_file_path
        self.inserts_file_path = inserts_file_path

        self.db_connection = None
        self.db_container = None

        logging.info(f"Oracledb version: {oracledb.__version__}")
        # If ORACLE_URL is set, already running in a container, no need for another DB container.
        self.using_db_container = not os.getenv("ORACLE_URL", "")
        if self.using_db_container:
            self.__init_db_container()

    def connect_to_db(self):
        if self.using_db_container:
            self.__start_db_container()
            logging.info("Oracle DB container started.")

            connection_url = self.db_container.get_connection_url()
            logging.info(f"Container connection URL: {connection_url}")

            # Extract user, password, host, port, and service name from connection_url
            # connection_url example: oracle+oracledb://system:0x537f1f@localhost:32772/?service_name=FREEPDB1
            import re
            match = re.match(r'oracle\+oracledb://([^:]+):([^@]+)@([^:]+):(\d+)/\?service_name=(\w+)', connection_url)
            if not match:
                raise ValueError("Failed to parse connection URL")

            user, password, host, port, service_name = match.groups()
            dsn = f"{host}:{port}/{service_name}"
            self.db_connection = self.__get_db_connection(user, password, dsn)

        else:
            dsn = os.environ["ORACLE_URL"]
            user = os.environ["ORACLE_USERNAME"]
            password = os.environ["ORACLE_PASSWORD"]

            self.db_connection = self.__get_db_connection(user, password, dsn)

        logging.info("DB Connection established.")

    def close_db_connection(self):
        self.__close_db_connection()

        if self.using_db_container:
            self.__stop_db_container()

    def __init_db_container(self):
        try:
            logging.info(f"Docker version: {docker.__version__}")
            self.db_container = OracleDbContainer("gvenzl/oracle-xe:21.3.0-slim-faststart")
            logging.info("Starting Oracle Container")
        except Exception as e:
            logging.error(f"Failed to initialize OracleDbContainer: {e}")
            raise e

    @staticmethod
    def __get_db_connection(user, password, dsn) -> oracledb.Connection:
        try:
            return oracledb.connect(user=user, password=password, dsn=dsn)
        except Exception as e:
            logging.error(f"Failed to connect to database: {e}")
            raise e

    def __start_db_container(self):
        try:
            self.db_container.start()
        except Exception as e:
            logging.error(f"Failed to start container: {e}")
            raise e

    def __stop_db_container(self):
        try:
            self.db_container.stop()
            logging.info("Oracle container stopped successfully.")
        except Exception as e:
            logging.error(f"Failed to stop container: {e}")
            raise e

    def __close_db_connection(self):
        try:
            if self.db_connection and self.db_connection.is_healthy():
                self.db_connection.close()
                logging.info("DB connection closed successfully.")
            else:
                logging.info("DB connection was already closed or not established.")
        except Exception as e:
            logging.error(f"Failed to close DB connection: {e}")
            raise e

    def __execute_sql_file(self, file_path):
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                sql = file.read()
                cursor = self.db_connection.cursor()
                for statement in sql.split(';\n'):
                    statement = statement.strip()
                    if statement.lower().startswith("create") or statement.lower().startswith(
                            "alter") or statement.lower().startswith("insert"):
                        if "SEGMENT CREATION DEFERRED" in statement:
                            statement = statement.replace("SEGMENT CREATION DEFERRED", "SEGMENT CREATION IMMEDIATE")
                        if "'DD.MM.RR HH24:MI:SSXFF'" in statement:
                            statement = statement.replace("'DD.MM.RR HH24:MI:SSXFF'", "'DD.MM.RR HH24:MI:SS,FF'")
                        cursor.execute(statement)
            logging.info(f"Executed SQL file: {file_path}")
        except Exception as e:
            logging.error(f"Failed to execute SQL file {file_path}: {e} - {statement}")
            raise e

    def initialize_schema(self):
        try:
            self.__execute_sql_file(self.schema_file_path)
            self.__execute_sql_file(self.inserts_file_path)
            logging.info("Schema initialized successfully.")
        except Exception as e:
            logging.error(f"Failed to initialize schema: {e}")
            raise e

    def execute_query(self, query: str):
        try:
            if "'DD.MM.RR HH24:MI:SSXFF'" in query:
                query = query.replace("'DD.MM.RR HH24:MI:SSXFF'", "'DD.MM.RR HH24:MI:SS,FF'")
            if query.endswith(';'):
                query = query[:-1]
            cursor = self.db_connection.cursor()
            cursor.execute(query)
            rows = cursor.fetchall()
            column_names = [desc[0] for desc in cursor.description]
            mapped_rows = [
                {col: val for col, val in zip(column_names, row)}
                for row in rows
            ]
            row_count = len(mapped_rows)
            return mapped_rows, row_count
        except Exception as e:
            logging.error(f"Failed to execute query: {e}")
            return None, None

