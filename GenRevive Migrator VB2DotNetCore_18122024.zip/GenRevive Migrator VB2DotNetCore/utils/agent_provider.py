import os

from crewai import Agent
from dotenv import load_dotenv
from genrevive.core.agent_factory import AgentFactory
from genrevive.core.common_tools.save_file_tool import save_file_tool
from genrevive.helpers.java.maven_build_tool import maven_build_tool


class AgentProvider:
    def __init__(self):
        load_dotenv()
        self.origin_technology = os.getenv("ORIGIN_TECHNOLOGY", "")
        self.target_technology = os.getenv("TARGET_TECHNOLOGY", "")
        self.origin_input = os.getenv("ORIGIN_INPUT", "")
        self.target_output = os.getenv("TARGET_OUTPUT", "")
        self.compiler_technology = os.getenv("COMPILER_TECHNOLOGY", "")
        self.save_file_tool = save_file_tool
        self.compiler_tool = maven_build_tool(with_tests=False, cache_success_only=True)

    def software_engineer(self) -> Agent:
        return AgentFactory().software_engineer(
            self.origin_technology,
            self.target_technology,
            self.origin_input,
            self.target_output,
            [],
        )

    def software_reviewer(self) -> Agent:
        return AgentFactory().software_reviewer(self.target_technology, [])

    def devops_engineer(self) -> Agent:
        return AgentFactory().devops_engineer(
            self.target_technology,
            self.compiler_technology,
            [self.save_file_tool, self.compiler_tool],
        )
