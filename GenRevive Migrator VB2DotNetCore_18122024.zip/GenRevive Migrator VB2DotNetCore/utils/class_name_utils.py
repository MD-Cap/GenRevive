class NameFactory:
    @staticmethod
    def from_vo_to_repository_name(vo_name: str) -> str:
        if "VO" in vo_name:
            return vo_name.replace("VO", "EORepository")
        elif "View" in vo_name:
            return vo_name.replace("View", "Repository")
        else:
            return vo_name  

    @staticmethod
    def from_repository_to_vo_name(repository_class_name: str) -> str:
        if "EORepository" in repository_class_name:
            return repository_class_name.replace("EORepository", "VO")
        elif "Repository" in repository_class_name:
            return repository_class_name.replace("Repository", "View")
        else:
            return repository_class_name  

    @staticmethod
    def from_vo_to_dto_name(vo_name: str) -> str:
        if "VO" in vo_name:
            return vo_name.replace("VO", "DTO")
        elif "View" in vo_name:
            return vo_name.replace("View", "DTO")
        else:
            return vo_name  

    # @staticmethod
    # def from_dto_to_vo_name(dto_class_name: str) -> str:
    #     if "DTO" in dto_class_name:
    #         return dto_class_name.replace("DTO", "VO")
    #     else:
    #         return dto_class_name  
