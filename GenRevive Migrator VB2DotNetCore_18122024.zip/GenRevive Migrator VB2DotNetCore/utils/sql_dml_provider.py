import sqlparse
import logging
import re
from sqlparse.sql import Identifier, Parenthesis


class SqlDmlProvider:
    def __init__(self, schema_file_path, insert_file_path):
        self.schema_file_path = schema_file_path
        self.insert_file_path = insert_file_path
        self.schema = {}
        self.inserts = {}
        self.load_files()

    def read_sql_file(self, file_path):
        """Reads SQL from a file and returns it as a string."""
        with open(file_path, "r", encoding="utf-8") as file:
            content = file.read()
        return content

    def parse_schema(self, schema_sql):
        """Parses SQL schema to identify tables and infer foreign key relationships."""
        table_keys = {}
        statements = sqlparse.parse(schema_sql)
        for statement in statements:
            if statement.get_type() == "CREATE":
                table_name = None
                foreign_keys = {}

                for token in statement.tokens:
                    if isinstance(token, Identifier) and not table_name:
                        table_name = token.get_real_name()

                    if isinstance(token, Parenthesis):
                        inside_parenthesis = token.value
                        fk_constraints = re.findall(
                            r"FOREIGN KEY \(([^)]+)\) REFERENCES ([^(]+)\(([^)]+)\)",
                            inside_parenthesis,
                            re.IGNORECASE,
                        )
                        for fk_column, ref_table, ref_column in fk_constraints:
                            foreign_keys[fk_column.strip()] = (
                                ref_table.strip(),
                                ref_column.strip(),
                            )

                if table_name:
                    table_keys[table_name] = {"foreign_keys": foreign_keys}
        return table_keys

    def parse_inserts(self, insert_sql):
        """Parses INSERT INTO statements from SQL content."""
        inserts = {}
        statements = sqlparse.split(insert_sql)
        regex = r"INSERT INTO\s+(\S+)"  # Regex to capture table name

        for statement in statements:
            match = re.search(regex, statement, re.IGNORECASE)
            if match:
                table_name = match.group(1)
                if table_name not in inserts:
                    inserts[table_name] = []
                inserts[table_name].append(statement)
        return inserts

    def load_files(self):
        """Loads and parses schema and insert SQL statements from files."""
        schema_sql = self.read_sql_file(self.schema_file_path)
        insert_sql = self.read_sql_file(self.insert_file_path)
        self.schema = self.parse_schema(schema_sql)
        self.inserts = self.parse_inserts(insert_sql)

    def get_sql_dml_by_table(self, target_table):
        """Resolves all dependencies before adding any insert from this table and returns the first insert if available."""
        collected = []
        seen = set()

        def _resolve(target_table):
            if target_table in seen:
                return
            seen.add(target_table)

            if target_table in self.inserts and self.inserts[target_table]:
                first_insert = self.inserts[target_table][0]
                fk_values_dict = self.extract_foreign_key_values(
                    first_insert, target_table
                )
                foreign_keys = self.schema.get(target_table, {}).get("foreign_keys", {})

                logging.debug(
                    f"Resolving foreign keys for {target_table}: {foreign_keys}"
                )

                # Resolve foreign key dependencies first
                for fk_column, (ref_table, ref_column) in foreign_keys.items():
                    if ref_table in self.schema:
                        ref_id = fk_values_dict.get(fk_column)
                        if ref_id is not None:
                            logging.debug(
                                f"Resolving {ref_table} for value {ref_id} in column {ref_column}"
                            )
                            _resolve_with_value(ref_table, ref_column, ref_id)

                # Collect the current insert statement after dependencies
                collected.append(first_insert)

        def _resolve_with_value(ref_table, ref_column, ref_value):
            for insert in self.inserts.get(ref_table, []):
                if self.check_insert_for_value(insert, ref_column, ref_value):
                    if insert not in collected:  # Avoid duplicate inserts
                        logging.debug(f"Adding {insert} for {ref_table}")
                        collected.append(insert)
                    break  # We assume we only need the first matching insert

        _resolve(target_table)
        if collected:
            return " ".join(
                collected
            )  # Join the collected list with spaces and return as a string
        else:
            return None

    def extract_foreign_key_values(self, insert_statement, table_name):
        """Extracts foreign key values from an insert statement based on the table schema."""
        fk_columns = list(
            self.schema.get(table_name, {}).get("foreign_keys", {}).keys()
        )
        if not fk_columns:
            logging.debug(f"No foreign key columns found for table {table_name}")
            return {}

        parsed = sqlparse.parse(insert_statement)[0]
        column_order = None
        values = []

        for token in parsed.tokens:
            if isinstance(token, sqlparse.sql.Values):
                # Extract values
                for sub_token in token.tokens:
                    if isinstance(sub_token, sqlparse.sql.Parenthesis):
                        value_tokens = sub_token.value.strip("()")
                        value_parsed = sqlparse.parse(value_tokens)[0]
                        for v_token in value_parsed.tokens:
                            if isinstance(v_token, sqlparse.sql.IdentifierList):
                                for identifier in v_token.get_identifiers():
                                    values.append(identifier.value.strip().strip("'"))
                            elif isinstance(v_token, sqlparse.sql.Identifier):
                                values.append(v_token.value.strip().strip("'"))
            elif isinstance(token, sqlparse.sql.Function):
                # Extract column names
                for sub_token in token.tokens:
                    if isinstance(sub_token, sqlparse.sql.Parenthesis):
                        column_order = [
                            col.strip()
                            for col in sub_token.value.strip("()").split(",")
                        ]

        if column_order is None or not values:
            logging.debug(
                f"Failed to extract column order or values for table {table_name} from statement: {insert_statement}"
            )
            return {}

        fk_values = {}
        for fk_col in fk_columns:
            if fk_col in column_order:
                fk_values[fk_col] = values[column_order.index(fk_col)]

        logging.debug(
            f"Extracted foreign key values {fk_values} for table {table_name} from statement: {insert_statement}"
        )
        return fk_values

    def check_insert_for_value(self, insert_statement, ref_column, ref_value):
        """Checks if an insert statement contains the reference value in the specified column."""
        parsed = sqlparse.parse(insert_statement)[0]
        column_order = None
        values = []

        for token in parsed.tokens:
            if isinstance(token, sqlparse.sql.Values):
                # Extract values
                for sub_token in token.tokens:
                    if isinstance(sub_token, sqlparse.sql.Parenthesis):
                        value_tokens = sub_token.value.strip("()")
                        value_parsed = sqlparse.parse(value_tokens)[0]
                        for v_token in value_parsed.tokens:
                            if isinstance(v_token, sqlparse.sql.IdentifierList):
                                for identifier in v_token.get_identifiers():
                                    values.append(identifier.value.strip().strip("'"))
                            elif isinstance(v_token, sqlparse.sql.Identifier):
                                values.append(v_token.value.strip().strip("'"))
            elif isinstance(token, sqlparse.sql.Function):
                # Extract column names
                for sub_token in token.tokens:
                    if isinstance(sub_token, sqlparse.sql.Parenthesis):
                        column_order = [
                            col.strip()
                            for col in sub_token.value.strip("()").split(",")
                        ]

        if column_order is None or not values:
            logging.debug(
                f"Failed to extract column order or values from statement: {insert_statement}"
            )
            return False

        if ref_column in column_order:
            return ref_value in values[column_order.index(ref_column)]

        return False


def main():
    sql_manager = SqlDmlProvider(".../changelog-1.sql", ".../changelog-2.sql")
    all_needed_inserts = sql_manager.get_sql_dml_by_table("S_EMP")
    print(all_needed_inserts)


if __name__ == "__main__":
    main()
