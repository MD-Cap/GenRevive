import logging
import re

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)


class SqlUtils:
    @staticmethod
    def extract_sql_content(markdown_text):
        # Regular expression to match everything between ```sql and ```
        sql_pattern = r"```sql\n# filename: (?P<filename>.*?)\n(?P<code>.*?)```"

        # Search for the pattern in the markdown text
        sql_blocks = re.finditer(sql_pattern, markdown_text, re.DOTALL)

        for code_block in sql_blocks:
            filename = code_block.group("filename").strip()
            sql_content = code_block.group("code").strip()
            return sql_content
        else:
            return None  # Return None if no match found
