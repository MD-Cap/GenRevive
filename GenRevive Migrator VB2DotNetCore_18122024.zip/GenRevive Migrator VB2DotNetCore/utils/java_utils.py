import logging
import os
import re

import javalang


class JavaUtils:
    def __init__(self, springboot_path):
        self.springboot_path = springboot_path
        logging.basicConfig(
            level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
        )

    def _read_file(self, file_path):
        with open(file_path, "r") as file:
            content = file.read()
            logging.debug(f"Read file: {file_path}")
            return content

    def _find_files(self, extension):
        java_files = []
        for root, _, files in os.walk(self.springboot_path):
            for file in files:
                if file.endswith(extension):
                    java_files.append(os.path.normpath(os.path.join(root, file)))
        logging.debug(f"Found {len(java_files)} files with extension {extension}")
        return java_files

    def _find_files_in_dir(self, extension, directory):
        java_files = []
        for root, _, files in os.walk(directory):
            for file in files:
                if file.endswith(extension):
                    java_files.append(os.path.normpath(os.path.join(root, file)))
        logging.debug(f"Found {len(java_files)} files with extension {extension}")
        return java_files

    def _extract_autowired_fields(self, content):
        # Pattern for field injection
        field_pattern = re.compile(r"@Autowired\s+private\s+(\w+)\s+(\w+);")
        autowired_fields = field_pattern.findall(content)

        # Pattern for constructor injection
        constructor_pattern = re.compile(r"@Autowired\s+public\s+\w+\s*\(([^)]+)\)")
        constructor_matches = constructor_pattern.findall(content)

        for constructor in constructor_matches:
            # Extracting all parameters in the constructor
            params = re.findall(r"\b(\w+)\s+(\w+)\b", constructor)
            autowired_fields.extend(params)

        logging.debug(f"Extracted autowired fields: {autowired_fields}")
        return autowired_fields

    def load_entity_based_on_repository_name(self, repository_name):
        # Construct the expected filename from the repository_name
        target_filename = f"{repository_name}.java"

        # Retrieve all Java files
        files = self._find_files(".java")
        for file in files:
            # Extract the filename from the file path
            filename = file.split(os.sep)[
                -1
            ]  # Adjust the split character depending on the OS if necessary
            if filename == target_filename:  # Check for exact match
                content = self._read_file(file)
                logging.debug(f"Checking repository file: {file}")

                # Ensure repository_name is within the content if more specificity is needed
                logging.debug(f"{repository_name} found in {file}")
                match = re.search(r"extends\s+JpaRepository\s*<\s*(\w+)\s*,", content)
                if match:
                    entity_name = match.group(1)
                    logging.info(
                        f"Entity based on repository {repository_name}: {entity_name}"
                    )
                    return entity_name
                else:
                    logging.debug(f"No match found for JpaRepository in {file}")

        # If no appropriate file is found or no match is made, return None
        return None

    def load_repositories_based_on_service_name(self, service_name):
        target_filename = f"{service_name}.java"
        files = self._find_files(".java")
        repositories = []

        for file in files:
            filename = file.split(os.sep)[-1]
            if filename == target_filename:
                content = self._read_file(file)
                repositories.extend(self._extract_autowired_fields(content))

        # Extract repository names
        repo_names = [repo for repo, _ in repositories]
        logging.info(f"Repositories for service {service_name}: {repo_names}")
        return repo_names

    def load_services_based_on_controller_name(self, controller_name):
        # Construct the expected filename from the controller_name
        target_filename = f"{controller_name}.java"

        # Retrieve all Java files
        files = self._find_files(".java")
        services = []
        for file in files:
            # Extract the filename from the file path
            filename = file.split(os.sep)[
                -1
            ]  # Adjust the split character depending on the OS if necessary
            if filename == target_filename:  # Check for exact match
                content = self._read_file(file)
                services.extend(self._extract_autowired_fields(content))

        # Collect service names
        service_names = [service for service, _ in services]
        logging.info(f"Services for controller {controller_name}: {service_names}")
        return service_names

    def load_dtos_based_on_repository_name(self, repository_name):
        # Construct the expected filename from the repository_name
        target_filename = f"{repository_name}.java"

        # Retrieve all Java files
        files = self._find_files(".java")
        dtos = set()  # Use a set to store DTO types to avoid duplicates
        for file in files:
            # Extract the filename from the file path
            # Extract the filename from the file path
            filename = file.split(os.sep)[
                -1
            ]  # Adjust the split character depending on the OS if necessary
            if filename == target_filename:  # Check for exact match
                content = self._read_file(file)
                # Regex to extract DTO types used in List return types within methods
                pattern = re.compile(r"\bList\s*<\s*(\w+)\s*>\s*\w+\(")
                dtos.update(pattern.findall(content))  # Add found DTOs to the set

        # Convert the set to a list before returning
        dtos_list = list(dtos)
        logging.info(f"DTOs for repository {repository_name}: {dtos_list}")
        return dtos_list

    def get_java_file_content_by_class_name(self, class_name):
        target_filename = f"{class_name}.java"
        files = self._find_files(".java")
        for file in files:
            filename = file.split(os.sep)[-1]
            if filename == target_filename:
                content = self._read_file(file)
                logging.info(f"File for class {class_name}: {file}")
                return content
        logging.warning(f"Class {class_name} not found in any Java file.")
        return None

    def extract_class_name_and_content(self, filepath):
        content = self._read_file(filepath)
        try:
            tree = javalang.parse.parse(content)

            package_name = None
            class_name = None

            # Extract package name
            if tree.package:
                package_name = tree.package.name

            # Extract class name
            for path, node in tree:
                if isinstance(node, javalang.tree.ClassDeclaration):
                    class_name = node.name
                    break

            if class_name:
                if package_name:
                    fully_qualified_name = f"{package_name}.{class_name}"
                else:
                    fully_qualified_name = class_name
                return fully_qualified_name, content

        except javalang.parser.JavaSyntaxError:
            logging.error(f"Syntax error in file: {filepath}")

        return None, None

    def build_class_name_to_file_content_map(self, root_dir):
        java_files = self._find_files_in_dir(".java", root_dir)
        class_map = {}

        for java_file in java_files:
            class_name, content = self.extract_class_name_and_content(java_file)
            file_path = java_file
            result = {class_name: {"filepath": file_path, "content": content}}
            class_map.update(result)

        return class_map
