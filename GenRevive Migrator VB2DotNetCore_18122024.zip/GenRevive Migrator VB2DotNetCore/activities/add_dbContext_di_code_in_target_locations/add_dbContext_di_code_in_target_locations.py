import logging
import os
import re
import shutil
import json
from pathlib import Path


from genrevive.core.base_activity import BaseActivity
from genrevive.helpers.common.logger import log_activity_execution


class AddDBContextDICodeInTargetLocations(BaseActivity):
    """
    add, update and deleted classess in the target location to make it work in MVC project.
    """

    def __init__(self):
        self.dotnet_service_implementation_path = os.environ["DOTNET_SERVICE_IMPLEMENTATION_PATH"]
        self.dotnet_project_name = os.environ["DOTNET_PROJECT_NAME"]
        self.dotnet_project_path = os.environ["DOTNET_PROJECT_PATH"]
        self.dotnet_service_interface_path = os.environ["DOTNET_SERVICE_INTERFACE_PATH"]
        self.dotnet_service_implementation_path = os.environ["DOTNET_SERVICE_IMPLEMENTATION_PATH"]

    @log_activity_execution
    
    def execute(self):
        self.__CreateMissingDBContextClassesAndAddDILines() 
    
    def __CreateMissingDBContextClassesAndAddDILines(self):
        isWriteToFile = 0
        lines_to_write = []
        services_line_to_write = []
        dbContextClass = ""
        dbcontext_name =""
        namespace = ""
        if os.path.exists(self.dotnet_service_implementation_path) and os.path.isdir(self.dotnet_service_implementation_path):
            files = [file for file in Path(self.dotnet_service_implementation_path).iterdir() if file.is_file()]
            for file in files:
                #print(Path(file).name)
                dbcontext_name = self.__Read_DBContext_Name(file)
                if not dbcontext_name == "":
                    #print(f"Found type: {dbcontext_name}")
                    dbContextClass = r"{0}\{1}.cs".format(self.dotnet_service_implementation_path, dbcontext_name)
                    #print(dbContextClass)
                    if os.path.exists(dbContextClass):
                        break
                    else:
                        # program.cs - add services - dependency injection
                        serviceClassName = Path(file).name.replace(".cs", "")
                        serviceInterfaceName = f"I{serviceClassName}"
                        services_line_to_write.append("")
                        services_line_to_write.append(f"builder.Services.AddScoped<{serviceInterfaceName}, {serviceClassName}>();")
                                            
                        # dbcontext
                        namespace = self.__Read_Namespace(file)
                        if (isWriteToFile == 0):
                            self.__Create_DataContext_Class(namespace, dbcontext_name, lines_to_write, isWriteToFile, file)
                            isWriteToFile = 1
                            self.__Create_DataContext_Class(namespace, dbcontext_name, lines_to_write, isWriteToFile, file)
                            #print(lines_to_write)
                        else:
                            self.__Create_DataContext_Class(namespace, dbcontext_name, lines_to_write, isWriteToFile, file)
                            #print(lines_to_write)

            if (isWriteToFile == 1):
                lines_to_write.append("")
                lines_to_write.append(" }")
                lines_to_write.append("}")
                # Write the array to a .cs file
                with open(dbContextClass, "w") as file:
                    for line in lines_to_write:
                        file.write(line + "\n")  # Add a newline character to each line
                        
                #update Program.cs class
                programFile = f"{self.dotnet_project_path}/Program.cs"
                self.__stab_lines_in_file(programFile, dbcontext_name, services_line_to_write, namespace)
            
    
    def __Create_DataContext_Class(self, namespace, dbcontext_name, lines_to_write, isFirstPart, file):
        if(isFirstPart == 0):
            using_namespace = namespace.replace("namespace","using").split('.')[0] + ".Models;"
            lines_to_write.append(using_namespace)
            lines_to_write.append("using Microsoft.EntityFrameworkCore;")
            lines_to_write.append("")
            lines_to_write.append("")
            lines_to_write.append(namespace)
            lines_to_write.append("{")
            lines_to_write.append(f"public class {dbcontext_name} : DbContext")
            lines_to_write.append("{")
            lines_to_write.append("")
            lines_to_write.append( f"  public {dbcontext_name}(DbContextOptions<{dbcontext_name}> options):base(options) ")  
            lines_to_write.append("   { }")   
            lines_to_write.append("") 
        else:
            className = Path(file).name.replace("Service.cs", "")
            classProperty = f"{className}s"
            classProperty = "Searches" if classProperty == "Searchs" else classProperty
            classProperty = "Splashes" if classProperty == "Splashs" else classProperty
            dbsetClassName = f"public DbSet<{className}> {classProperty}" 
            lines_to_write.append(dbsetClassName)
            lines_to_write.append("{ get; set; }")
            lines_to_write.append("")
         
    def __Read_DBContext_Name(self, source_file_path):
        context_type = ""
        try:
            ctor_line_of_code = r"public {0}(".format( Path(source_file_path).name.replace(".cs",""))
            # Open and read the file
            with open(source_file_path, 'r') as file:
                for line in file:
                    # Check if the line contains 'public UserService('
                    if ctor_line_of_code in line:
                        #print(f"Found line: {line.strip()}")
                        pattern = r'\((\w+)\s+(\w+)\)'
                        # Search for the pattern in the line
                        match = re.search(pattern, line.strip())
                        if match:
                            # Extract the type and the variable name
                            context_type = match.group(1)
                            #print(f"Found type: {context_type}")
                            break
            return context_type
        except Exception as e:
            print(f"An error occurred: {e}")       
   
    def __Read_Namespace(self, source_file_path):
            namespace = ""
            try:
                ns_line_of_code = r"namespace"
                # Open and read the file
                with open(source_file_path, 'r') as file:
                    for line in file:
                        # Check if the line contains 'public UserService('
                        if ns_line_of_code in line:
                                namespace = line
                                #print(f"Found type: {context_type}")
                                break
                return namespace
            except Exception as e:
                print(f"An error occurred: {e}")       
    
    def __stab_lines_in_file(self, filename, dbcontext_name, lines_to_insert, namespace):
        """
        Inserts lines between two specific lines in a file.
        """
        # Read the file content
        with open(filename, 'r') as file:
            lines = file.readlines()
    
        # Prepare the new content
        new_content = []
        
        new_content.append("using Microsoft.EntityFrameworkCore;")
        new_content.append("\n")
        
        if namespace == "":
            new_content.append(f"using {self.dotnet_project_name}.{self.dotnet_service_interface_path.split('/')[-1]};")
            new_content.append("\n")
            new_content.append(f"using {self.dotnet_project_name}.{self.dotnet_service_implementation_path.split('/')[-1]};")
            new_content.append("\n")
        else:
            new_content.append(namespace.replace("namespace","using") + ";")
            new_content.append("\n")
            
        new_content.append("\n")
        for line in lines:
            if "Add services to the container" in line:
                new_content.append(line)
                new_content.append("\n")
                new_content.append("builder.Services.AddDbContext<"+dbcontext_name+">(options =>") 
                new_content.append("\n")
                new_content.append(f"        options.UseSqlServer(builder.Configuration.GetConnectionString(\"DefaultConnection\")));")
                new_content.append("\n")
                for newLine in lines_to_insert:
                    new_content.append(newLine)
                    new_content.append("\n")
                new_content.append("\n")
            else:
                new_content.append(line)
        
        # Write the modified content back to the file
        with open(filename, 'w') as file:
            file.writelines(new_content)
        
    def __get_first_level_folders(self, source_folder):
        return [subfolder for subfolder in Path(source_folder).iterdir() if subfolder.is_dir()]              
            
    def __modify_text_and_save(self, source_file_path, destination_file_path, old_text, new_text):
        try:
            # Read the content of the source file
            with open(source_file_path, 'r') as file:
                lines = file.readlines()

            updated_lines = [
                line.replace(old_text, new_text) for line in lines
            ]
              # Save the modified content to the destination file
            with open(destination_file_path, 'w') as file:
                file.writelines(updated_lines)

            print(f"Modified file saved successfully to {destination_file_path}")

        except Exception as e:
            print(f"An error occurred: {e}")        

   

    
