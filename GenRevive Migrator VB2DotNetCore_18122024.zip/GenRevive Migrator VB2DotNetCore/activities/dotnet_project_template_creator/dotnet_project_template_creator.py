import logging
import os
import shutil
import json

from genrevive.core.base_activity import BaseActivity
from genrevive.helpers.common.logger import log_activity_execution


class DotNetProjectTemplateCreator(BaseActivity):
    """
    This class creates a Microsoft .NET MCV Project Template that serves as the Output Project of this Migrator.
    """

    def __init__(self):

        self.dotnet_ai_response_directory = os.environ["DOTNET_AI_RESPONSE_PATH"]
        self.dotnet_projects_directory = os.environ["DOTNET_PROJECTS_DIRECTORY"]
        self.dotnet_project_name = os.environ["DOTNET_PROJECT_NAME"]
        self.dotnet_project_path = os.environ["DOTNET_PROJECT_PATH"]
        self.dotnet_service_interface_path = os.environ["DOTNET_SERVICE_INTERFACE_PATH"]
        self.dotnet_service_implementation_path = os.environ["DOTNET_SERVICE_IMPLEMENTATION_PATH"]
        self.repo_package_name = os.environ["REPOSITORY_PACKAGE_NAME"]
        
        self.dev_config_connection_string = os.environ["DOTNET_DEV_CONFIG_CONNECTION_STRING"]
       
    @log_activity_execution
    def execute(self):
        self.__CreateDotNetTemplate("mvc") # parameter value: mvc, webapi
        self.__InstallNuGetPackages() # add nuget packages
        self.__AddDevConfigurations() # add dev configuration
        self.__BuildCreatedProjectAndsolution() # build project and check no compilation error
        self.__CreateServiceInterfaceAndImplementationPath() # create provisional service interface and implementation path
        self.__CreateAIResponseStagingPath() # create provisional (staging) AI generated code path

        
    def __CreateDotNetTemplate(self, templateType):
        # create the solution path if it doesn't exist yet
        # templateType mvc, webapi
        print(self.dotnet_projects_directory)
        if (os.path.exists(self.dotnet_projects_directory) == False):
            os.mkdir(self.dotnet_projects_directory)
            
         # this is the command that will be run in order to create a new project.  Customising the project before creation would occur here
        command = "dotnet.exe new {} --name {} --force".format(templateType, self.dotnet_project_name)
        result = self.__ExecuteCommand(command, self.dotnet_projects_directory)[0]
        if result:
            print("Project successfully created")
        else:
            print("Project not created")
            
         # this is the command that will be run in order to create a new xunit test project.  Customising the project before creation would occur here
        test_project_name = self.dotnet_project_name+"_Tests"
        command = "dotnet.exe new {} --name {} --force".format("xunit", test_project_name)
        result = self.__ExecuteCommand(command, self.dotnet_projects_directory)[0]
        if result:
            print("Test Project successfully created")
        else:
            print("Test Project not created")
            
         # this is the command that will be run in order to create a new sln.  Customising the project before creation would occur here
        command = "dotnet.exe new sln --name {} --force".format(self.dotnet_project_name)
        result = self.__ExecuteCommand(command, self.dotnet_project_path)[0]
        if result:
            print("Solution successfully created")
        else:
            print("Solution not created")
        
        logging.info(f"Dot Net Project new solution (.sln) is created with the status success: {result}")
             
        # this is the command used to add the project to the solution
        csproj_path = r"{0}\{1}.csproj".format(self.dotnet_project_path, self.dotnet_project_name)
        command = 'dotnet.exe sln add "{}"'.format(csproj_path)
        result = self.__ExecuteCommand(command, self.dotnet_project_path)[0]
        if result:
            print("Project successfully added to the solution")
        else:
            print("Project not added to the solution")
        
        # add test project to the solution     
        csproj_path = r"..\{0}\{1}.csproj".format(test_project_name, test_project_name)
        command = 'dotnet.exe sln add "{}"'.format(csproj_path)
        result = self.__ExecuteCommand(command, self.dotnet_project_path)[0]
        if result:
            print("Test Project successfully added to the solution")
        else:
            print("Test Project not added to the solution")
            
        logging.info(f"Dot Net Project (.*proj) added to the solution (.sln) with the status success: {result}")
    
    
    def __InstallNuGetPackages(self):
        # add nuget packages to the project
        
        command = "dotnet add package Microsoft.EntityFrameworkCore -v 7.0.20"
        command_result = self.__ExecuteCommand(command, self.dotnet_project_path)
        
        # Install SqlServer
        command = "dotnet add package Microsoft.EntityFrameworkCore.SqlServer -v 7.0.20"
        command_result = self.__ExecuteCommand(command, self.dotnet_project_path)
        
         # Install EF Tools
        command = "dotnet add package Microsoft.EntityFrameworkCore.Tools -v 7.0.20"
        command_result = self.__ExecuteCommand(command, self.dotnet_project_path)
        
        logging.info(f"Successfully added all NuGet packages")
    
    def __AddDevConfigurations(self):
        config_data = {     
        "DefaultConnection": self.dev_config_connection_string 
        }
        # Load appsettings.json
        with open(r"{0}\appsettings.json".format(self.dotnet_project_path), "r") as file:
            app_settings = json.load(file)
        # Add ConnectionStrings section if it doesn't already exist
        if "ConnectionStrings" not in app_settings:
            app_settings["ConnectionStrings"] = config_data
        print(app_settings)
        # Optionally, save the updated app_settings back to appsettings.json
        with open(r"{0}\appsettings.json".format(self.dotnet_project_path), "w") as file:
            json.dump(app_settings, file, indent=4)   
        
        logging.info(f"Successfully added connection string in appsettings file") 
    
    def __BuildCreatedProjectAndsolution(self):
        command = "dotnet.exe build SOLUTION"
        result = self.__ExecuteCommand(command, self.dotnet_project_path)[0]
        if result:
            print("Successfully build solution")
        else:
            print("Failed to build solution")
            
        logging.info(f"Dot Net solution build with the status success: {result}")
        
    def __CreateServiceInterfaceAndImplementationPath(self):
        # service implementation and interface path
        print(self.dotnet_service_interface_path)
        if (os.path.exists(self.dotnet_service_interface_path) == False):
            os.mkdir(self.dotnet_service_interface_path)
        
        print(self.dotnet_service_implementation_path)
        if (os.path.exists(self.dotnet_service_implementation_path) == False):
            os.mkdir(self.dotnet_service_implementation_path)
            
        logging.info(f"Successfully created service implementaion and interface path")
        
    def __CreateAIResponseStagingPath(self):
        # create AI Response Staging folder
        ai_staging_path = r"{0}\{1}".format(self.dotnet_projects_directory, self.dotnet_ai_response_directory)
        if (os.path.exists(ai_staging_path) == False):
            os.mkdir(ai_staging_path)
            
        logging.info(f"Successfully created staging path to save AI response")
        
    def __ExecuteCommand(self, command, file_path):
        # if the file path exists and is not empty, change to the directory else return False and "File path not valid"
        if file_path != None and os.path.exists(file_path):
            os.chdir(file_path)
        else:
            return False, "File path not valid" # False depicts that the command did not run successfully due to the invalid file path
        command_output = os.popen(command).read() # command is executed
        return True, command_output # True depicts that the command was executed successfully, however, it might not be the desired out put which is why the command_output is also returned
    
 
