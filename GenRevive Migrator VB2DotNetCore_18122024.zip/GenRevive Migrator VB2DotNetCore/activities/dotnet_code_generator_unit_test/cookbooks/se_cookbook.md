## Backend

### Input:

- The root folder of the main project containing controller and service classes.
- A destination folder in the test project for the generated test files.

### Features:

- Parse the source project for all classes with the following characteristics:
- Controllers: Classes inheriting from ControllerBase or decorated with [Controller].
- Services: Classes implementing specific service interfaces or containing "Service" in their names under ServiceInterface and ServiceImplementation folder.
- Extract all public methods in these classes.
- For each method, generate:
    - Unit tests for success cases (mock dependencies where needed).
    - Unit tests for edge cases and exceptions (e.g., null inputs, invalid arguments).

### Output:

- Controllers Test: Create subfolder "Controllers" 
- Services Test: Create subfolder "Services"
- xUnit test files in the destination folder with test classes named as <ClassName>Tests.
- Each test method should follow the Arrange-Act-Assert pattern.

### Additional Features:

- Use Moq to mock dependencies.
- Provide comments in the generated code to help developers customize the tests.
- Optionally, detect constructor dependencies and mock them automatically.
