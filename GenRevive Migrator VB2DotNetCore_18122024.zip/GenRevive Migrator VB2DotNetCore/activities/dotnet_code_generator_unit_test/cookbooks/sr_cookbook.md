# cookbook

Respect all points in the Review cookbook and ensure that is implemented correctly.

## Rules

- Ensure Entity Framework (EF) class is created with the entity name from the `Name` attribute in the `<Entity>` tag
- Translate SQL column type `NUMERIC` to appropriate .net data types in the entity model (e.g., `VARCHAR` to `string`, `DATE` to `DateTime`, `TIMESTAMP` to `DateTime`).
  - Translate SQL column type `NUMERIC` based on those rules:
  - Oracle NUMBER(7, 0) to `int`
  - Oracle NUMBER(9,0) to `int`
  - Oracle NUMBER(10, 0) to `int`
  - Oracle NUMBER(11, 2) to `decimal`
  - Oracle NUMBER(19,0) to `Long`
  - Oracle DATE to `DateTime`
  - Oracle TIMESTAMP to `DateTime`

