import os
import logging
import traceback


class JavaEntityMocksUtil:
    """
    The JavaEntityMocksUtil class generates Java entity mock classes based on a provided list of entity names.
    It uses a predefined template to create these classes and writes them to the appropriate directory within a specified project path.
    The template contains the minimal content for a Spring Boot entity, using Lombok annotations
    for boilerplate code like constructors, getters, setters, and the @Entity annotation for JPA mapping.
    """

    def __init__(self, package_name, project_path):

        self.template = """\
package {package};

import jakarta.persistence.*;
import lombok.*;

@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class {entity_class} {{

    @Id
    private Integer id;
}}
"""
        self.package_name = package_name
        self.project_path = project_path + "/" + self.package_name.replace(".", "/")

        # Log initial configuration
        logging.debug(
            f"Initialized JavaEntityGenerator with package_name: {self.package_name}"
        )
        logging.debug(f"Project path set to: {self.project_path}")

    def generate_entity_mocks(self, entities):
        directory = os.path.join(self.project_path)
        logging.debug(f"Directory path for Java files: {directory}")

        try:
            # Ensure the directory exists; if not, create it
            os.makedirs(directory, exist_ok=True)
        except Exception as e:
            logging.error(f"Failed to create directory: {directory}. Error: {e}")
            logging.error(traceback.format_exc())
            raise

        file_path = ""  # Initialize file_path to handle exceptions better
        try:
            # Loop over each entity and generate a Java file
            for entity in entities:
                logging.debug(f"Processing entity: {entity}")
                # Use Python's string formatting to inject package name and entity class name into the template
                file_content = self.template.format(
                    package=self.package_name, entity_class=entity
                )
                # Construct the path for the new Java file
                file_path = os.path.join(directory, f"{entity}.java")
                logging.debug(f"File path to be written: {file_path}")

                with open(file_path, "w") as file:
                    file.write(file_content)
                logging.info(f"File written successfully: {file_path}")
        except Exception as e:
            logging.error(f"Failed to write file: {file_path}. Error: {e}")
            logging.error(traceback.format_exc())
            raise


if __name__ == "__main__":
    generator = JavaEntityMocksUtil()
    entity_names = ["CountryEO", "CityEO", "RegionEO"]
    try:
        generator.generate_entity_mocks(entity_names)
    except Exception as e:
        logging.critical(f"An error occurred: {e}")
        logging.critical(traceback.format_exc())
