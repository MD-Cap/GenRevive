import os
from pathlib import Path

from dotenv import load_dotenv
from genrevive.core.callbacks import save_code_blocks
from genrevive.core.gen_ai_activity import GenAIActivity
from genrevive.core.task_factory import TaskFactory
from genrevive.helpers.common.file_utils import FileUtils
from genrevive.helpers.common.markdown_renderer import MarkdownRenderer
from utils.agent_provider import AgentProvider


class DotnetCodeGeneratorUnitTests(GenAIActivity):
    """
    Generated code cleanup 
    """

    def __init__(self):
        self.dotnet_project_path = ""

        self.se_prompt = ""
        self.se_cookbook = ""
        self.sr_prompt = ""
        self.sr_cookbook = ""
        self.devops_prompt = ""
        self.transitive_prompt = ""

        self.software_engineer = None
        self.software_reviewer = None
        self.devops_engineer = None
        self.agents = []

        self.tasks = []

        os.environ["GENERATOR_HOME_PATH"] = os.path.dirname(os.path.abspath(__file__))
        load_dotenv(override=True)
        load_dotenv("activities/.env", override=True)
        
        self.dotnet_projects_directory = os.environ["DOTNET_PROJECTS_DIRECTORY"]
        self.dotnet_ai_response_directory = os.environ["DOTNET_AI_RESPONSE_PATH"]
        self.dotnet_project_name = os.environ["DOTNET_PROJECT_NAME"]
        self.dotnet_project_path = os.environ["DOTNET_PROJECT_PATH"]

        super().__init__()

    def setup_general_configuration(self):
        self.dotnet_project_path = os.getenv("DOTNET_PROJECT_PATH", "")


    def setup_cookbooks_and_prompts(self):
        self.se_prompt = FileUtils.read_file(os.getenv("SE_PROMPT_FILE", ""))
        self.se_cookbook = FileUtils.read_file(os.getenv("SE_COOKBOOK_FILE", ""))


    def setup_agents(self):
        self.software_engineer = AgentProvider().software_engineer()
        self.agents = [
            self.software_engineer,
        ]

    def setup_tasks(self):
        test_project_name = self.dotnet_project_name+"_Tests"
        target_file_path = r"{0}\{1}".format(self.dotnet_projects_directory, test_project_name)
        
        unit_test_source_files = self.__read_source_file()
        #print(unit_test_source_files)

        self.__generate_unittest_code_ai_assistance_task(
            unit_test_source_files,
            target_file_path
        )
                
        
    def __generate_unittest_code_ai_assistance_task(
        self,
        source_files,
        target_file_path,
    ):
      for source_file in source_files:
           # Normalize the file path for consistent separators
            normalized_path = os.path.normpath(f"{source_file}")
            # Extract the directory path
            directory_path = os.path.dirname(normalized_path)
            # Get the last folder name
            last_folder = os.path.basename(directory_path)
            file_name_only = os.path.splitext(os.path.basename(f"{source_file}"))[0].replace(" ", "")
            target_file_path_with_filename = os.path.join(target_file_path, last_folder, f"{file_name_only}_tests.cs")
            
            # Create the directory if it doesn't exist
            os.makedirs(target_file_path_with_filename, exist_ok=True)
            
            #print(target_file_path_with_filename)
            cleaned_elements = normalized_path.replace("{", "").replace("}", "").replace("'", "")
                        
            # Open and read the file
            with open(cleaned_elements, 'r') as file:
                content = file.read() 
                #print(content)

            input = {"Class": {"type": ".cs", "content": content}}
            
            se_prompt_rendered_markdown = self.se_prompt.format(
                file_name=target_file_path_with_filename
            )
            input_contents_rendered_markdown = MarkdownRenderer.render_dict_to_markdown(input)

            self.tasks.append(
                TaskFactory().task_code_translation(
                    agent=self.software_engineer,
                    prompt=se_prompt_rendered_markdown,
                    cookbook=self.se_cookbook,
                    input=input_contents_rendered_markdown,
                    target_technology_names=["xUnit Test"],
                    target_file_path=target_file_path_with_filename,
                    callback=save_code_blocks,
                )
            )
                       
            
    def __get_first_level_folders(self, source_folder):
        return [subfolder for subfolder in Path(source_folder).iterdir() if subfolder.is_dir() and (subfolder.name == "Controllers" or subfolder.name == "ServiceImplementation") ]       
            
    def __find_source_folders(self, root_dir):
    # List to store full paths of target folders
        found_paths = []
        targeted_folders = ["Controllers", "ServiceImplementation"]
        # Walk through the directory tree
        for dirpath, dirnames, filenames in os.walk(root_dir):
            for folder in targeted_folders:
                if folder in dirnames:
                    # Add the full path to the found folder
                    found_paths.append(os.path.join(dirpath, folder))
        
        return found_paths        

    def __read_source_file(self):
        cs_files = []
        unit_test_source_folders = self.__find_source_folders(self.dotnet_project_path)
        
        for subfolderItem in unit_test_source_folders:
            for root, dirs, files in os.walk(subfolderItem):
                for file_name in files:
                    if file_name.endswith(".cs"):
                        file_path = os.path.join(root, file_name)
                        cs_files.append({file_path})
            
        return cs_files             

    
