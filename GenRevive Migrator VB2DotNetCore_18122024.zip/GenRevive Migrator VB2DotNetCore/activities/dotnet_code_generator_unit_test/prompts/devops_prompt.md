Use the .net compiler to check whether the .net code blocks are functional.
If you discover any errors, return the whole .net code and the error message to the Software Engineer.
Always pass the original .net code as context and let the Software Engineer correct the .net code.
Only correct the .net code, do not make any changes to the structure of the project file.
in their own separate .net class 'files' within the same package on file system.
The mock classes are .net core Entities that should only contain the minimum nesseccary contents, be indicated by a comment
