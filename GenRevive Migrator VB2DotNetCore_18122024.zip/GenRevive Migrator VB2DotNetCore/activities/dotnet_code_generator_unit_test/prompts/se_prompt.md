**Note:** All code generatiion needs to resolve dependencies.

Develop a script or tool that reads all classes from the controllers and ServiceImplementation folder in a ASP.Net MVC C# project and generates corresponding xUnit test files in a test project. The generated tests should include basic unit tests for public methods with Arrange-Act-Assert structure.

