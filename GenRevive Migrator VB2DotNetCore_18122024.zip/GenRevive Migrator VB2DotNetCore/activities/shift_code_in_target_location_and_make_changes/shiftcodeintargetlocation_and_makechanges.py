import logging
import os
import shutil
import json
from pathlib import Path
import difflib
import re


from genrevive.core.base_activity import BaseActivity
from genrevive.helpers.common.logger import log_activity_execution


class ShiftCodeInTargetLocationAndMakeChanges(BaseActivity):
    """
    Shift AI generated code in target MVC project location and make changes to make it work in MVC project.
    """

    def __init__(self):
        self.dotnet_ai_response_directory = os.environ["DOTNET_AI_RESPONSE_PATH"]
        self.dotnet_projects_directory = os.environ["DOTNET_PROJECTS_DIRECTORY"]
        self.dotnet_project_name = os.environ["DOTNET_PROJECT_NAME"]
        self.dotnet_project_path = os.environ["DOTNET_PROJECT_PATH"]
        self.dotnet_service_interface_path = os.environ["DOTNET_SERVICE_INTERFACE_PATH"]
        self.dotnet_service_implementation_path = os.environ["DOTNET_SERVICE_IMPLEMENTATION_PATH"]

    @log_activity_execution
    
    def execute(self):
        self.__MoveGeneratedFileToTargetProjectLocation() 
        

    def __MoveGeneratedFileToTargetProjectLocation(self):
         generated_file_source_path = r"{0}\{1}".format(self.dotnet_projects_directory, self.dotnet_ai_response_directory)
         top_level_subfolders_generated_source = self.__get_first_level_folders(generated_file_source_path)
         for subfolderItem in top_level_subfolders_generated_source:
            level2_subfolders_generated_source = self.__get_first_level_folders(subfolderItem) 
            for Level2SubfolderItem in level2_subfolders_generated_source:
                folders = [subfolder for subfolder in Level2SubfolderItem.iterdir() if subfolder.is_dir()] # is level2 subfolder contains next level sub folder(s)
                if any(folders):
                    for folder in folders:
                        dotcode_target_folder = r"{0}\{1}\{2}".format(self.dotnet_project_path, Path(Level2SubfolderItem).name, Path(folder).name)
                        print(dotcode_target_folder)
                        
                        # Ensure the destination folder exists
                        os.makedirs(dotcode_target_folder, exist_ok=True)
                        
                        files = [file for file in folder.iterdir() if file.is_file()]
                        for file in files:
                            dotcode_target_file_path = r"{0}\{1}".format(dotcode_target_folder, Path(file).name)
                            print(dotcode_target_file_path)
                            self.__modify_text_and_save(file, dotcode_target_file_path, self.dotnet_ai_response_directory, self.dotnet_project_name)
                else:    
                    servicesFolderName = Path(Level2SubfolderItem).name
                    files = [file for file in Level2SubfolderItem.iterdir() if file.is_file()] # copy all files
                    for file in files:
                        dotcode_target_file_path = r"{0}\{1}\{2}".format(self.dotnet_project_path, Path(Level2SubfolderItem).name, Path(file).name)
                        if (servicesFolderName.lower() == "services"):
                            service_dest_path = self.__check_interface_or_implementation_file_type_return_target_path(file)
                            if not service_dest_path == "":
                                dotcode_target_file_path = r"{0}\{1}".format(service_dest_path, Path(file).name)
                        
                        print(dotcode_target_file_path)
                        self.__modify_text_and_save(file, dotcode_target_file_path, self.dotnet_ai_response_directory, self.dotnet_project_name)
        
   
    def __get_first_level_folders(self, source_folder):
        return [subfolder for subfolder in Path(source_folder).iterdir() if subfolder.is_dir()]              
            
    def __modify_text_and_save(self, source_file_path, destination_file_path, namespace_text_generated, namespace_text_replacement):
        try:
            # Read the content of the source file
            with open(source_file_path, 'r') as file:
                lines = file.readlines()

            sourcefile_updated_lines = [
                line.replace(namespace_text_generated, namespace_text_replacement) for line in lines
            ]
            
            #print(f"Source Path: {source_file_path}; Length: {len(lines)}")
            print(f"Dest Path: {destination_file_path}")
            
            # check file exists in the destination path
            if os.path.exists(destination_file_path):
                with open(destination_file_path, 'r') as file:
                    existing_file_lines = file.readlines()
                    print(f"updated_lines count:{len(sourcefile_updated_lines)} - existingLines count: {len(existing_file_lines)}")
                    sourcefile_updated_lines = self.__compare_texts_and_amalgamate(sourcefile_updated_lines, existing_file_lines)

            # Save the modified content to the destination file
            with open(destination_file_path, 'w') as file:
                file.writelines(sourcefile_updated_lines)

            print(f"Modified file saved successfully to {destination_file_path}")

        except Exception as e:
            print(f"An error occurred: {e}")        

   
    def __compare_texts_and_amalgamate(self, linesInFile1, linesInFile2):
        # Create a Differ object
        differ = difflib.Differ()
        difflinesTop = []
        difflines = []
        diff = []
        # Compare the lines
        diff = list(differ.compare(linesInFile2, linesInFile1))
        if len(diff) > 0:
            for line in diff:
                if line.startswith('+ '):
                    newLineText = line.replace("+", " ").strip()
                    if not newLineText in [' ', '', '\n']:
                        self.__write_code_implementation_lines(linesInFile1, newLineText, difflines, difflinesTop)
            
            
            checkLastCurlyBrCounts = self.__check_last_two_lines_contains_specific_char(linesInFile2)
            
            consLines = difflinesTop + linesInFile2[:checkLastCurlyBrCounts] + ["\n"] + difflines + linesInFile2[checkLastCurlyBrCounts:] #[-2:] indicates last two lines 
        else:
            consLines = linesInFile2
            
        return consLines

    def __write_code_implementation_lines(self, linesInFile1, search_text, difflines, difflinesTop):
        try:
            print(f"Search text: {search_text}")
            for index, line in enumerate(linesInFile1):
                if search_text in line:
                    print(f"Found '{search_text}' at index {index}.")
                    
                    if "using " in search_text:
                        difflinesTop.append(search_text) 
                        difflinesTop.append("\n")
                    else:
                        if not search_text == "}":
                            difflines.append(search_text) 
                            difflines.append("\n")
                        if not search_text.endswith(('}', ']', ';')):
                            i = linesInFile1[index+1]
                            for i in enumerate(linesInFile1):
                                item = linesInFile1[i].strip()
                                if item.startswith("}"):
                                    difflines.append(item) 
                                    difflines.append("\n")
                                    print(f"Found '}}' at index {index}.")
                                    break
                                else:
                                    difflines.append(item) 
                                    difflines.append("\n")
        except ValueError:
            print(f"'{search_text}' not found in the array.")
       
    def __check_interface_or_implementation_file_type_return_target_path(self, sourceFile):
        rtnVal = ""
        with open(sourceFile, 'r') as file:
                lines = file.readlines()
                
        for line in lines:
            if " interface " in line:
                rtnVal = self.dotnet_service_interface_path # interface
                break
            else:
                if " class " in line:
                    rtnVal = self.dotnet_service_implementation_path
                    break
        
        return rtnVal
    
    def __check_last_two_lines_contains_specific_char(self, lines):
        rtnVal = 0
        if len(lines) >= 2:
            if "}" in lines[-1]:
                rtnVal = -1
            if "}" in lines[-2]:
                rtnVal = -2
        return rtnVal