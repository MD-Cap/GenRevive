import os

from dotenv import load_dotenv
from genrevive.core.callbacks import save_code_blocks
from genrevive.core.gen_ai_activity import GenAIActivity
from genrevive.core.task_factory import TaskFactory
from genrevive.helpers.common.file_utils import FileUtils
from genrevive.helpers.common.markdown_renderer import MarkdownRenderer
from utils.agent_provider import AgentProvider


class VBToDotNetCodeGenerator(GenAIActivity):
    """
    The VBToDotNetCodeGenerator class takes VB6 code files to transform them into Microsoft .NET core model classes, service interface, 
    service implementation, controller, front end, css style and javascript.
    """

    def __init__(self):
        self.dotnet_project_path = ""

        self.se_prompt = ""
        self.se_cookbook = ""
        self.sr_prompt = ""
        self.sr_cookbook = ""
        self.devops_prompt = ""
        self.transitive_prompt = ""

        self.software_engineer = None
        self.software_reviewer = None
        self.devops_engineer = None
        self.agents = []

        self.tasks = []

        os.environ["GENERATOR_HOME_PATH"] = os.path.dirname(os.path.abspath(__file__))
        load_dotenv(override=True)
        load_dotenv("activities/.env", override=True)
        
        self.dotnet_projects_directory = os.environ["DOTNET_PROJECTS_DIRECTORY"]
        self.dotnet_ai_response_directory = os.environ["DOTNET_AI_RESPONSE_PATH"]
        self.vb_source_directory = os.environ["VB_PROJECT_PATH"]
        self.dotnet_project_name = os.environ["DOTNET_PROJECT_NAME"]

        super().__init__()

    def setup_general_configuration(self):
        self.dotnet_project_path = os.getenv("DOTNET_PROJECT_PATH", "")


    def setup_cookbooks_and_prompts(self):
        self.se_prompt = FileUtils.read_file(os.getenv("SE_PROMPT_FILE", ""))
        self.se_cookbook = FileUtils.read_file(os.getenv("SE_COOKBOOK_FILE", ""))
       
        '''
        self.sr_prompt = FileUtils.read_file(os.getenv("SR_PROMPT_FILE", ""))
        self.sr_cookbook = FileUtils.read_file(os.getenv("SR_COOKBOOK_FILE", ""))

        self.devops_prompt = FileUtils.read_file(os.getenv("DEVOPS_PROMPT_FILE", ""))

        self.transitive_prompt = FileUtils.read_file(
            os.getenv("TRANSITIVE_PROMPT_FILE", "")
        )
        '''

    def setup_agents(self):
        self.software_engineer = AgentProvider().software_engineer()
        #self.software_reviewer = AgentProvider().software_reviewer()
        #self.devops_engineer = AgentProvider().devops_engineer()
        self.agents = [
            self.software_engineer,
            #self.software_reviewer,
            #self.devops_engineer,
        ]

    def setup_tasks(self):
        target_file_path = r"{0}\{1}".format(self.dotnet_projects_directory, self.dotnet_ai_response_directory)

        all_frm_input_files = self.__read_vb_source_file()
        
        print("call __append_vb_to_dotnet_ai_assistance_task")
        self.__append_vb_to_dotnet_ai_assistance_task(
            all_frm_input_files,
            target_file_path,
        )
    
    def __read_vb_source_file(self):
        # Directory to search for .frm files
        # List to store .frm files
        frm_files = []

        # Walk through the directory
        for root, dirs, files in os.walk(self.vb_source_directory):
            for file in files:
                if file.endswith(".frm"):
                    frm_files.append(os.path.join(root, file))
        return frm_files           

    def __append_vb_to_dotnet_ai_assistance_task(
        self,
        all_frm_input_files,
        target_file_path,
    ):
        for file_entity_name in all_frm_input_files:
            file_name_only = os.path.splitext(os.path.basename(file_entity_name))[0].replace(" ", "")
            target_file_path_with_filename = os.path.join(target_file_path, file_name_only)
            # Create the directory if it doesn't exist
            os.makedirs(target_file_path_with_filename, exist_ok=True)

            # Open and read the file
            with open(file_entity_name, 'r', encoding='utf-8') as file:
                content = file.read() 

            input = {"VB6": {"type": ".frm", "content": content}}
            
            se_prompt_rendered_markdown = self.se_prompt.format(
                file_name=file_entity_name
            )
            input_contents_rendered_markdown = MarkdownRenderer.render_dict_to_markdown(input)

            self.tasks.append(
                TaskFactory().task_code_translation(
                    agent=self.software_engineer,
                    prompt=se_prompt_rendered_markdown,
                    cookbook=self.se_cookbook,
                    input=input_contents_rendered_markdown,
                    target_technology_names=["ASP.NET MVC"],
                    target_file_path=target_file_path_with_filename,
                    callback=save_code_blocks,
                )
            )
            
            
            
            

    

    
