**Note:** Generate code within MVC folder structure and equivalent .NET MVC application components (controllers, models, views, services and serviceInterfaces) from VB6 forms, modules, and database interactions. 

## Backend

### Models
- **{ClassName}.cs**
  - Properties with the correct Column annotations which will use to create column of a database table. 
  - DO NOT add Model as suffix in the ClassName

### ServiceInterface
- **I{Name}Service.cs**
  - Methods

### ServiceImplementation
- **{Name}Service.cs**
  - Code

### Controllers
- **{Name}Controller.cs** 
  - Code

**Note:** When generating the Controller, ensure it is linked with the service and whereever it is applicable.

## Frontend

### Views
- **{Name}.cshtml** 
- HTML code (Don't add boilerplate template) 

### style.css
- Style code

### JS code
- **{Name}.JS** 
- jQuery code
