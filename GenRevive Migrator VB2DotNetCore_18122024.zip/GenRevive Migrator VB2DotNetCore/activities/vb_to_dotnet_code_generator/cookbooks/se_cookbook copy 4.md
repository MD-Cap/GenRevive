## Backend

### DBModel
- **{ClassName}.cs**
  - Properties with the correct annotations which will use to create column of a database table.
  - DO NOT add Model as suffix in the ClassName
  - Add property with dependency data model class whereever it is applicable

### Service Interface
- **I{Name}Service.cs**
  - Methods

### Service Implementation
- **{Name}Service.cs**
  - Code

### Controller
- **{Name}Controller.cs** 
  - Code

**Note:** When generating the Controller, ensure it is linked with the service. 

## Frontend

### Views
- **{Name}.cshtml** 
- HTML code (Don't add boilerplate template)

### style.css
- Style code

### JS code
- **{Name}.JS** 
- jQuery code